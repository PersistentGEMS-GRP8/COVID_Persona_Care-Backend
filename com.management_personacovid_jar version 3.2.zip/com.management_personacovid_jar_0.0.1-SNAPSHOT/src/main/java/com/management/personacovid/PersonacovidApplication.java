package com.management.personacovid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonacovidApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonacovidApplication.class, args);
	}

}
