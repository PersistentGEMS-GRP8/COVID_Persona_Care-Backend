/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.management.personacovid.service;

import com.management.personacovid.model.Doctor;
import java.util.List;

/** @author Encryptor_95 */
public interface DoctorService {
List<Doctor> getAllDoctor();

}
