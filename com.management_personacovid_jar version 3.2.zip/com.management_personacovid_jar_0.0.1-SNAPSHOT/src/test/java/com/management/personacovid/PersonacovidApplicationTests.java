package com.management.personacovid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonacovidApplicationTests {

	@Test
	void contextLoads() {
	}

}
